"""
    Equipo docente de Autómatas y Lenguajes Curso 2024-25
    Última modificación: 26 de septiembre de 2024

    Implementación de un autómata. Para ello, se van a definir las siguientes clases:
        - State: Clase que define un estado del autómata.
        - Transitions: Clase que define el conjunto de transiciones del autómata.
        - FiniteAutomaton: Clase que define el autómata finito.
        - REParser: Clase que parsea de expresión regular a autómata.
"""

from src.state import State
from src.transitions import Transitions
from src.utils import is_deterministic
from collections import deque

class FiniteAutomaton():
    """
        Define un autómata finito.
    """

    def __init__(self, initial_state: State, states: set, symbols: set, transitions: Transitions):

        if initial_state not in states:
            raise ValueError(
                f"Initial state {initial_state.name} "
                f"is not in the set of states",
            )

        self.initial_state = initial_state
        self.states = states
        self.symbols = symbols
        self.transitions = transitions
        self.states_count = 0
        

    def __eq__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented

        return (
            self.initial_state == other.initial_state
            and self.states == other.states
            and self.symbols == other.symbols
            and self.transitions == other.transitions
        )

    def __repr__(self):
        return (
            f"{type(self).__name__}("
            f"initial_state={self.initial_state!r}, "
            f"states={self.states!r}, "
            f"symbols={self.symbols!r}, "
            f"transitions={self.transitions!r})"
        )

    # BEGIN Funciones relacionadas con las transiciones

    def add_transition(self, start_state: State, symbol: str, end_state: State):
        self.transitions.add_transition(start_state, symbol, end_state)
        
    def add_transitions(self, transitions: list):
        self.transitions.add_transitions(transitions)

    def has_transition(self, state: State, symbol: str):
        return self.transitions.state_has_any_transition_with_symbol(state, symbol)
        
    def get_transition(self, state: State, symbol: str):
        return self.transitions.goes_to(state, symbol)
        
    def get_all_transitions(self):
        return self.transitions.get_all_transitions()

    # END Funciones relacionadas con las transiciones


    # BEGIN Funciones relacionadas con el procesamiento de una cadena

    def reset(self):
        """
        Resetea el autómata volviendo al estado inicial.
        
        Args: No args
        
        Returns: No return
        """
        # Establece el conjunto de estados actuales al estado inicial del autómata.
        # `current_states` inicia en el estado inicial especificado en el autómata.
        current_states = {self.initial_state}
        
        # Actualiza `self.current_states` con la clausura-lambda del estado inicial,
        # es decir, añade todos los estados alcanzables mediante transiciones lambda desde el inicial.
        self.current_states = self._complete_lambdas(current_states)

    def process_symbol(self, symbol: str):
        """
        Procesa un símbolo de entrada.
        
        Args:
            symbol: símbolo a consumir en el autómata.
        
        Returns: No return
        """
        # Inicializa un conjunto vacío para almacenar los estados alcanzables.
        next_states = set()

        # Itera sobre cada estado en `self.current_states`.
        for state in self.current_states:
            # Verifica si existe una transición desde el estado actual usando el símbolo.
            if self.has_transition(state, symbol):
                # Si la transición existe, agrega los estados de destino al conjunto `next_states`.
                next_states.update(self.get_transition(state, symbol))

        # Actualiza `self.current_states` con la clausura-lambda de los estados alcanzados,
        # para incluir los estados alcanzables mediante transiciones lambda.
        self.current_states = self._complete_lambdas(next_states)


    def accepts(self, string: str):
        """
            Esta función procesa una cadena y comprueba si debe ser aceptada
              o no.

            Args:
                string: cadena a procesar

            Returns:
                True si la cadena debe ser aceptada
                False otherwise
        """
        self.reset()
        for symbol in string:
            self.process_symbol(symbol)

        # comprobar si alguno de los últimos estados al que transiciona mediante la cadena, es estado final
        return any(state.is_final for state in self.current_states)


    def _complete_lambdas(self, raw_current_states: set):
        """
        Esta función añade al conjunto de estados actuales todos aquellos
        estados que pueden ser alcanzados con el símbolo lambda (transiciones epsilon).
        
        Args:
            raw_current_states: conjunto de estados actuales al que se le deben añadir
            todos aquellos estados a los que se puede transitar mediante transiciones lambda.
        
        Return:
            Conjunto de estados actualizado, incluyendo los alcanzables a través de λ-transiciones.
        
        Observación:
            - Es recomendable utilizar el método `get_lambda_transitions` de Transitions
            para obtener las transiciones λ.
        """
        
        # Se crea un conjunto `complete_states` que contiene los estados originales,
        # para asegurarnos de no modificar el conjunto original directamente.
        complete_states = set(raw_current_states)

        # Obtenemos las transiciones lambda (transiciones ε) desde el objeto `transitions`.
        # El método `get_lambda_transitions` debería devolver un diccionario donde
        # las claves son los estados y los valores son los conjuntos de estados alcanzables
        # mediante transiciones λ desde esos estados.
        lambda_state = self.transitions.get_lambda_transitions()

        # Inicializamos una cola para realizar un recorrido en amplitud (BFS).
        # Comenzamos con los estados proporcionados en `raw_current_states`.
        queue = deque(raw_current_states)

        # Bucle principal que recorre la cola mientras haya estados por procesar.
        while queue:
            state = queue.popleft()  # Sacamos un estado de la cola para procesarlo.
            
            # Si el estado actual tiene transiciones lambda, las procesamos.
            if state in lambda_state:
                for next_states in lambda_state[state]:
                    # Si el siguiente estado no ha sido añadido a `complete_states`,
                    # lo agregamos y lo ponemos en la cola para seguir procesándolo.
                    if next_states not in complete_states:
                        complete_states.add(next_states)
                        queue.append(next_states)

        # Finalmente, devolvemos el conjunto completo de estados, que incluye
        # los estados alcanzables mediante transiciones lambda.
        return complete_states


    # END Funciones relacionadas con el procesamiento de una cadena

    # BEGIN Funciones relacionadas con generar el AFD
    def to_deterministic(self):
        """
        Convierte un Autómata Finito No Determinista con transiciones λ (AFN-λ)
        a un Autómata Finito Determinista (AFD).
        
        Args: No args
        
        Return:
            Un autómata finito determinista.
        """
        
        # Inicializamos un diccionario para almacenar los estados del AFD
        # y un objeto de transiciones para el AFD.
        states = dict()  # Almacena estados con sus respectivas clausuras
        transitions = Transitions()  # Administrador de transiciones del AFD

        # Calculamos la clausura-lambda del estado inicial del AFN-λ
        # para definir el estado inicial del AFD.
        initial_closure = frozenset(self._complete_lambdas({self.initial_state}))
        
        # Creamos el estado inicial del AFD combinando los nombres de los estados en la clausura
        # y verificamos si es un estado final.
        state_ini = State(
            name=''.join(state.name for state in initial_closure),
            is_final=any(state.is_final for state in initial_closure)
        )

        # Asociamos la clausura inicial con el estado inicial en el diccionario de estados.
        states[initial_closure] = state_ini

        # Lista que almacena las clausuras de estados que faltan por procesar.
        unprocessed_states = [initial_closure]

        # Bucle principal para procesar todos los estados aún sin procesar.
        while unprocessed_states:
            # Extraemos una clausura sin procesar.
            current_closure = unprocessed_states.pop()
            # Obtenemos el estado correspondiente a esta clausura en el AFD.
            current_state = states[current_closure]

            # Iteramos sobre cada símbolo del alfabeto para generar las transiciones del AFD.
            for symbol in self.symbols:
                # Conjunto para almacenar los estados alcanzables con el símbolo actual.
                states_lambda = set()
                
                # Para cada estado en la clausura actual, buscamos sus transiciones con el símbolo.
                for state in current_closure:
                    states_no_lambda = self.get_transition(state, symbol)
                    if states_no_lambda is not None:
                        # Completamos las transiciones con clausura-lambda y añadimos al conjunto.
                        states_lambda.update(self._complete_lambdas(states_no_lambda))

                # Convertimos el conjunto de estados alcanzables en una clausura inmutable.
                states_lambda = frozenset(states_lambda)

                # Verificamos si ya existe en el diccionario de estados.
                if states_lambda in states:
                    # Si existe, añadimos una transición hacia ese estado.
                    transitions.add_transition(current_state, symbol, states[states_lambda])
                    continue
                else:
                    # Si no existe, creamos un nuevo estado en el AFD.
                    new_state = State(
                        name=''.join(state.name for state in states_lambda),
                        is_final=any(state.is_final for state in states_lambda)
                    )

                    # Añadimos la nueva transición y registramos el nuevo estado en el diccionario.
                    transitions.add_transition(current_state, symbol, new_state)
                    states[states_lambda] = new_state
                    
                    # Agregamos la nueva clausura a la lista para procesar sus transiciones.
                    unprocessed_states.append(states_lambda)

        # Finalmente, retornamos un nuevo autómata finito determinista con:
        # - El estado inicial, el conjunto de estados, los símbolos y las transiciones.
        return FiniteAutomaton(states[initial_closure], set(states.values()), self.symbols, transitions)

    def to_minimized(self):
        """
        Minimiza un Autómata Finito Determinista (DFA).
        
        Returns:
            Un autómata finito determinista minimizado.
        """
        
        # Verifica que el autómata sea determinista antes de continuar.
        if not is_deterministic(self):
            raise ValueError("El autómata debe ser determinista")

        # Inicializa el estado inicial y una estructura para almacenar todos los estados alcanzables.
        state_ini = self.initial_state
        states_total = {state_ini}  # Conjunto de estados alcanzables desde el estado inicial.
        queue = deque([state_ini])  # Cola para procesar estados alcanzables.

        # Bucle para encontrar todos los estados accesibles a partir del estado inicial.
        while len(queue) > 0:
            state = queue.popleft()
            for symbol in self.symbols:
                # Obtiene el estado alcanzable con el símbolo actual.
                next_states = list(self.transitions.goes_to(state, symbol))[0]
                
                # Si el estado alcanzado no ha sido registrado, se añade a la cola y al conjunto.
                if next_states not in states_total:
                    queue.append(next_states)
                    states_total.add(next_states)

        # Convierte el conjunto de estados alcanzables a una lista para su manipulación en el proceso de minimización.
        states_total = list(states_total)

        # Inicializa la partición inicial: 0 para estados no finales, 1 para estados finales.
        partitions = [1 if state.is_final else 0 for state in states_total]
        new_partition = [-1] * len(states_total)  # Nueva partición para iteraciones

        # Variable para controlar la estabilidad de las particiones (cuando ya no cambian).
        stable = False
        while not stable:
            stable = True  # Asumimos inicialmente que la partición es estable.
            partition_map = {}  # Diccionario para mapear particiones de estados.

            # Asigna cada estado a una nueva partición basándose en su "firma" (grupo y transiciones).
            for i, state in enumerate(states_total):
                # Inicializa la firma con el grupo actual del estado.
                signature = (partitions[i],)
                
                # Añade a la firma el grupo de cada estado alcanzable por cada símbolo.
                for symbol in self.symbols:
                    next_state = list(self.transitions.goes_to(state, symbol))[0]
                    signature += (partitions[states_total.index(next_state)], )

                # Añade el índice del estado al grupo correspondiente según su firma.
                if signature not in partition_map:
                    partition_map[signature] = []
                partition_map[signature].append(i)

            # Asigna nuevos índices de partición y actualiza `new_partition`.
            for new_index, states in enumerate(partition_map.values()):
                for state_index in states:
                    # Si un estado cambia de partición, la partición no es estable.
                    if new_partition[state_index] != new_index:
                        new_partition[state_index] = new_index
                        stable = False

            # Actualiza la partición para la siguiente iteración.
            partitions = new_partition[:]

        # Inicialización de listas para los estados y transiciones del AFD minimizado.
        states_final = []
        transitions_final = Transitions()
        final_states = set()

        # Crea un estado representativo para cada partición y determina si es final.
        for part_id in range(max(partitions) + 1):
            representative_index = partitions.index(part_id)
            representative_state = states_total[representative_index]
            states_final.append(representative_state)

            # Si el estado representativo es final, se añade al conjunto de estados finales.
            if representative_state.is_final:
                final_states.add(representative_state)

        # Añade las transiciones al AFD minimizado.
        for state in states_final:
            for symbol in self.symbols:
                # Obtiene el índice de la partición del estado alcanzable.
                next_state_index = states_total.index(list(self.transitions.goes_to(state, symbol))[0])
                
                # Añade la transición usando el estado representativo de la partición alcanzada.
                transitions_final.add_transition(state, symbol, states_final[partitions[next_state_index]])

        # Define el estado inicial del AFD minimizado como el representativo de la partición del estado inicial.
        state_ini_final = states_final[partitions[states_total.index(self.initial_state)]]

        # Retorna el AFD minimizado, incluyendo el estado inicial, los estados, los símbolos y las transiciones.
        return FiniteAutomaton(state_ini_final, states_final, self.symbols, transitions_final)
